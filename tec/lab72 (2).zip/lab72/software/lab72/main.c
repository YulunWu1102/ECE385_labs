#include "text_mode_vga_color.h"


int main(){
	textVGAColorScreenSaver();
	return 0;
}
